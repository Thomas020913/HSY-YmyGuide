package com.thomas.ymyguide.dataBaseServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataBaseServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
