package com.thomas.ymyguide.dataBaseServer.traveler.controller;

import com.thomas.ymyguide.dataBaseServer.traveler.entity.Traveler;
import com.thomas.ymyguide.dataBaseServer.traveler.service.TravelerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/traveler")
public class TravelerController {
    @Autowired
    private TravelerService service;

    @PostMapping("/add")
    public ResponseEntity<String> addTraveler(@RequestBody Traveler traveler) {
        service.addUserInfo(traveler.getUsername(), traveler.getPhone(), traveler.getPassword(), 1);
        return ResponseEntity.ok("Traveler added successfully");
    }

    @GetMapping("/getAllTravelers")
    public ResponseEntity<java.util.List<com.thomas.ymyguide.dataBaseServer.traveler.entity.Traveler>> getAllTravelers() {
        return ResponseEntity.ok(service.getAllTravelers());
    }
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteTraveler(@RequestParam String username) {
        boolean success = service.deleteUserByUsername(username);
        if (success) {
            return ResponseEntity.ok("用户删除成功");
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("未找到该用户名");
        }
    }
    @PutMapping("/update")
    public ResponseEntity<String> updateTraveler(@RequestBody Traveler traveler) {
        boolean updated = service.updateTravelerByUsername(traveler.getUsername(), traveler.getPhone(), traveler.getPassword());
        return updated ? ResponseEntity.ok("更新成功") : ResponseEntity.badRequest().body("更新失败");
    }
} 