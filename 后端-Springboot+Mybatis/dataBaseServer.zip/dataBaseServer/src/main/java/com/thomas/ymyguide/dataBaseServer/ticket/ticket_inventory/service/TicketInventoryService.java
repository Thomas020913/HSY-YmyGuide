package com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.service;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.entity.TicketInventory;
import com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.mapper.TicketInventoryMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketInventoryService {
    @Autowired
    private TicketInventoryMapper ticketInventoryMapper;

    public void addOrUpdateTicket(TicketInventory ticket, int addStock) {
        TicketInventory existing = ticketInventoryMapper.selectByNameAndType(ticket.getTicketName(), ticket.getTicketType());

        if (existing != null) {
            // 仅更新库存
            ticketInventoryMapper.updateStock(ticket.getTicketName(), ticket.getTicketType(), addStock);
        } else {
            // 插入新记录（赋值库存）
            ticket.setCurrentStock(addStock);
            ticket.setTotalStock(addStock);
            ticketInventoryMapper.insertTicket(ticket);
        }
    }
    public void delOrUpdateTicket(TicketInventory ticket, int delStock) {
        TicketInventory existing = ticketInventoryMapper.selectByNameAndType(ticket.getTicketName(), ticket.getTicketType());

        if (existing != null) {
            // 仅更新库存
            ticketInventoryMapper.updateStock(ticket.getTicketName(), ticket.getTicketType(), delStock);
        } else {
            // 插入新记录（赋值库存）
            ticket.setCurrentStock(delStock);
            ticket.setTotalStock(delStock);
            ticketInventoryMapper.insertTicket(ticket);
        }
    }

    public List<TicketInventory> getAllTicketInventory() {
        return ticketInventoryMapper.getAllTicketInventory();
    }

    @Autowired
    private TicketInventoryMapper mapper;

    public boolean decreaseStock(String ticketName, String ticketType, int quantity) {
        int updatedRows = mapper.decreaseStock(ticketName, ticketType, quantity);
        return updatedRows > 0; // 如果更新成功（库存充足），返回 true，否则 false
    }


}


