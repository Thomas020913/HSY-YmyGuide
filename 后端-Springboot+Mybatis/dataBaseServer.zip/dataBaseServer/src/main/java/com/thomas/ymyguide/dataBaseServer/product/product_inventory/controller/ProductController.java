package com.thomas.ymyguide.dataBaseServer.product.product_inventory.controller;

import com.thomas.ymyguide.dataBaseServer.product.product_inventory.entity.Product;
import com.thomas.ymyguide.dataBaseServer.product.product_inventory.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/product")
public class ProductController {

    @Autowired
    private ProductService service;

    @GetMapping("/list")
    public ResponseEntity<List<Product>> listProducts() {
        List<Product> products = service.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @PostMapping("/add")
    public ResponseEntity<String> addProduct(@RequestBody Map<String, String> request) {
        Product product = new Product();
        product.setName(request.get("product_name"));
        product.setCategory(request.get("category"));
        product.setPrice(Double.parseDouble(request.get("price")));
        product.setStock(Integer.parseInt(request.get("stock")));
        product.setImageUrl(request.get("image_url"));
        product.setScenicSpotId(Integer.parseInt(request.get("scenic_spot_id")));
        product.setDescription("无");
        product.setIsOnSale(1);
        service.addProduct(product);
        return ResponseEntity.ok("产品添加成功");
    }

    @PostMapping("/update")
    public ResponseEntity<String> updateProductStock(@RequestBody Map<String, Object> map) {
        String productName = (String) map.get("product_name");
        Integer quantity = (Integer) map.get("quantity");
        if (productName == null || quantity == null) {
            return ResponseEntity.badRequest().body("参数缺失");
        }
        boolean result = service.updateProductStock(productName, quantity);
        if (result) {
            return ResponseEntity.ok("库存更新成功");
        } else {
            return ResponseEntity.badRequest().body("库存不足或商品不存在");
        }
    }
    @PostMapping("/detail")
    public ResponseEntity<?> getProductDetail(@RequestBody Map<String, Integer> request) {
        try {
            Integer productId = request.get("productId");
            if (productId == null) {
                return ResponseEntity.badRequest().body("商品ID不能为空");
            }

            Product product = service.getProductById(productId);
            if (product == null) {
                return ResponseEntity.notFound().build();
            }

            Map<String, Object> response = new HashMap<>();
            response.put("id", product.getId());
            response.put("name", product.getName());
            response.put("price", product.getPrice());
            response.put("description", product.getDescription());
            response.put("stock", product.getStock());
            response.put("imageUrl", product.getImageUrl());

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("获取商品详情失败：" + e.getMessage());
        }
    }

    @PostMapping("/delete")
    public ResponseEntity<String> deleteProduct(@RequestBody Map<String, String> request) {
        Product product = new Product();
        product.setName(request.get("product_name"));
        service.deleteProduct(product);
        return ResponseEntity.ok("success");
    }

}
