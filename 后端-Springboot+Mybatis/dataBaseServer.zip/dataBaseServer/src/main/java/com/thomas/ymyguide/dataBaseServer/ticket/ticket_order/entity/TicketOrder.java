package com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.entity;

import lombok.Data;
import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
public class TicketOrder {
    private Integer orderId;         // 自增主键
    private String orderNumber;      // 客户端生成的订单号
    private String ticketType;       // 票种信息
    private BigDecimal ticketPrice;  // 票价
    private Integer quantity;        // 购票数量
    private BigDecimal totalAmount;  // 总金额
    private String orderStatus;      // 订单状态（默认为未核销）
    private Timestamp createTime;    // 下单时间
} 