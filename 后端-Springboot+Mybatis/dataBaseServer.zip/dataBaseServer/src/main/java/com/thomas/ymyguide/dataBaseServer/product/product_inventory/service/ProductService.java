package com.thomas.ymyguide.dataBaseServer.product.product_inventory.service;

import com.thomas.ymyguide.dataBaseServer.product.product_inventory.entity.Product;
import com.thomas.ymyguide.dataBaseServer.product.product_inventory.mapper.ProductMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    private ProductMapper productMapper;

    public List<Product> getAllProducts() {
        return productMapper.getAllProducts();
    }

    public void addProduct(Product product) {
        productMapper.insertProduct(product);
    }
    public void deleteProduct(Product product) { productMapper.deleteProduct(product);}

    @Transactional
    public boolean updateProductStock(String productName, Integer quantity) {
        return productMapper.updateProductStock(productName, quantity) > 0;
    }

    public Product getProductById(Integer productId) {
        return productMapper.getProductById(productId);
    }
}
