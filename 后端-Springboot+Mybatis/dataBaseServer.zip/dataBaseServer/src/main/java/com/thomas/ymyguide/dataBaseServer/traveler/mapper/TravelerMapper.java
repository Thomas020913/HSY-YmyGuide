package com.thomas.ymyguide.dataBaseServer.traveler.mapper;

import org.apache.ibatis.annotations.*;
import com.thomas.ymyguide.dataBaseServer.traveler.entity.Traveler;
import org.springframework.data.repository.query.Param;

@Mapper
public interface TravelerMapper {

    @Insert("INSERT INTO user_info (username, phone, password, role) VALUES (#{username}, #{phone}, #{password}, #{role})")
    void insertUserInfo(String username, String phone, String password, int role);

    @Select("SELECT * FROM user_info WHERE role = 1")
    java.util.List<Traveler> selectAllTravelers();

    @Delete("DELETE FROM user_info WHERE username = #{username}")
    int deleteByUsername(String username);

    @Update("UPDATE user_info SET phone = #{phone}, password = #{password} WHERE username = #{username}")
    int updateTraveler(String username, String phone, String password);

} 