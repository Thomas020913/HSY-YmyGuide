package com.thomas.ymyguide.dataBaseServer.product.product_order.mapper;

import com.thomas.ymyguide.dataBaseServer.product.product_order.entity.ProductOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface ProductOrderMapper {
    boolean insertOrder(ProductOrder order);
    
    boolean updateOrderStatus(@Param("orderNumber") String orderNumber, @Param("status") String status);
    
    ProductOrder getOrderByNumber(@Param("orderNumber") String orderNumber);
} 