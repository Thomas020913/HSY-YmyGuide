package com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.mapper;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.entity.TicketInventory;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Mapper
public interface TicketInventoryMapper {
    TicketInventory selectByNameAndType(@Param("ticketName") String ticketName, @Param("ticketType") String ticketType);

    void updateStock(@Param("ticketName") String ticketName, @Param("ticketType") String ticketType, @Param("addStock") int addStock);

    void insertTicket(TicketInventory ticket);

    @Select("SELECT * FROM ticket_inventory")
    List<TicketInventory> getAllTicketInventory();

    int decreaseStock(String ticketName, String ticketType, int quantity);
}


