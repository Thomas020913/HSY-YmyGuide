package com.thomas.ymyguide.dataBaseServer.product.product_order.controller;

import com.thomas.ymyguide.dataBaseServer.product.product_order.entity.ProductOrder;
import com.thomas.ymyguide.dataBaseServer.product.product_order.service.ProductOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.sql.Timestamp;
import java.util.Map;
import java.math.BigDecimal;
import java.math.RoundingMode;

@RestController
@RequestMapping("/api/product_order")
public class ProductOrderController {
    @Autowired
    private ProductOrderService service;

    @PostMapping("/create")
    public ResponseEntity<String> createOrder(@RequestBody Map<String, Object> map) {
        try {
            // 验证必要参数
            if (!map.containsKey("orderNumber") || !map.containsKey("price") || !map.containsKey("quantity")) {
                return ResponseEntity.badRequest().body("Missing required parameters");
            }

            ProductOrder order = new ProductOrder();
            order.setOrderNumber((String) map.get("orderNumber"));
            
            // 获取并验证数量
            int quantity = map.get("quantity") == null ? 1 : (Integer) map.get("quantity");
            if (quantity <= 0) {
                return ResponseEntity.badRequest().body("Invalid quantity");
            }
            order.setQuantity(quantity);
            
            // 获取并验证价格
            double price;
            try {
                price = Double.parseDouble(map.get("price").toString());
                if (price <= 0) {
                    return ResponseEntity.badRequest().body("Invalid price");
                }
            } catch (NumberFormatException e) {
                return ResponseEntity.badRequest().body("Invalid price format");
            }
            
            // 计算总价（保留两位小数）
            BigDecimal totalPrice = new BigDecimal(price * quantity)
                .setScale(2, RoundingMode.HALF_UP);
            order.setTotalPrice(totalPrice);
            
            // 设置订单状态和时间
            order.setOrderStatus("未完成");
            order.setPaymentTime(new Timestamp(System.currentTimeMillis()));
            
            // 创建订单
            boolean result = service.createOrder(order);
            if (result) {
                return ResponseEntity.ok("success");
            } else {
                return ResponseEntity.badRequest().body("Failed to create order");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/verify")
    public ResponseEntity<String> verifyOrder(@RequestBody Map<String, Object> map) {
        try {
            // 验证必要参数
            if (!map.containsKey("orderNumber") || !map.containsKey("status")) {
                return ResponseEntity.badRequest().body("Missing required parameters");
            }

            String orderNumber = (String) map.get("orderNumber");
            String status = (String) map.get("status");

            // 验证并更新订单状态
            boolean result = service.verifyAndUpdateOrder(orderNumber, status);
            if (result) {
                return ResponseEntity.ok("success");
            } else {
                return ResponseEntity.badRequest().body("Order not found");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        }
    }
} 