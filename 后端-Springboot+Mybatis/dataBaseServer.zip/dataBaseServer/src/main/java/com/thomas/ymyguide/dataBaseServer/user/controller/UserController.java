package com.thomas.ymyguide.dataBaseServer.user.controller;

import com.thomas.ymyguide.dataBaseServer.user.entity.UserRequest;
import com.thomas.ymyguide.dataBaseServer.user.dto.ResponseData;
import com.thomas.ymyguide.dataBaseServer.user.service.UserService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<Integer> login(@RequestBody UserRequest userRequest) {
        String username = userRequest.getUsername();
        String password = userRequest.getPassword();

        int role = userService.validateLogin(username, password);
        return ResponseEntity.ok(role);
    }
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody UserRequest registerRequest) {
        ResponseData res = userService.registerUser(registerRequest);

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            String message;

            if (res.isSuccess()) {
                // 构造一个包含success和message的JSON对象
                return ResponseEntity.ok(objectMapper.writeValueAsString(new ResponseData(true, res.getMessage())));
            } else {
                return ResponseEntity.ok(objectMapper.writeValueAsString(new ResponseData(false, res.getMessage())));
            }
        } catch (IllegalArgumentException e) {
            return ResponseEntity.ok("{\"success\":false, \"message\":\"" + e.getMessage() + "\"}");
        } catch (Exception e) {
            return ResponseEntity.ok("{\"success\":false, \"message\":\"系统错误，请稍后再试\"}");
        }
    }
}