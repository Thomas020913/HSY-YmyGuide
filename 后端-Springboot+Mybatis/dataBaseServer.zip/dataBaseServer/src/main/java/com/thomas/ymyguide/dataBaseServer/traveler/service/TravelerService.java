package com.thomas.ymyguide.dataBaseServer.traveler.service;

import com.thomas.ymyguide.dataBaseServer.traveler.entity.Traveler;
import com.thomas.ymyguide.dataBaseServer.traveler.mapper.TravelerMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.security.MessageDigest;
import java.util.List;

@Service
public class TravelerService {
    @Autowired
    private TravelerMapper mapper;

    public void addUserInfo(String username, String phone, String password, int role) {
        mapper.insertUserInfo(username, phone, password, role);
    }

    public java.util.List<Traveler> getAllTravelers() {
        return mapper.selectAllTravelers();
    }
    public boolean deleteUserByUsername(String username) {
        int affected = mapper.deleteByUsername(username);
        return affected > 0;
    }
    public boolean updateTravelerByUsername(String username, String phone, String password) {
        String encryptedPassword = md5Encrypt(password); // MD5 加密
        int affectedRows = mapper.updateTraveler(username, phone, encryptedPassword);
        return affectedRows > 0;
    }

    private String md5Encrypt(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            // 转为16进制字符串
            StringBuilder sb = new StringBuilder();
            for (byte b : messageDigest) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (Exception e) {
            throw new RuntimeException("MD5加密失败", e);
        }
    }
} 