package com.thomas.ymyguide.dataBaseServer.scenicSpot.entity;

public class ScenicSpotSimpleDTO {
    private String audioUrl;
    private String name;
    private String intro;
    private String imageUrl;

    public ScenicSpotSimpleDTO() {}

    public ScenicSpotSimpleDTO(String name, String intro, String imageUrl, String audioUrl) {
        this.name = name;
        this.intro = intro;
        this.imageUrl = imageUrl;
        this.audioUrl = audioUrl;
    }

    public String getName() {return name;}

    public void setName(String name) {
        this.name = name;
    }

    public String getIntro() {
        return intro;
    }

    public void setIntro(String intro) {
        this.intro = intro;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getAudioUrl() {return audioUrl;}

    public void setAudioUrl(String audioUrl) {
        this.audioUrl = audioUrl;
    }
} 