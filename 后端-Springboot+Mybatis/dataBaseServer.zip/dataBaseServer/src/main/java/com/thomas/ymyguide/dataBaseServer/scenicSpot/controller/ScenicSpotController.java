package com.thomas.ymyguide.dataBaseServer.scenicSpot.controller;

import com.thomas.ymyguide.dataBaseServer.scenicSpot.entity.ScenicSpot;
import com.thomas.ymyguide.dataBaseServer.scenicSpot.entity.ScenicSpotSimpleDTO;
import com.thomas.ymyguide.dataBaseServer.scenicSpot.service.ScenicSpotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/scenic")
public class ScenicSpotController {
    @Autowired
    private ScenicSpotService service;

    @PostMapping("/list")
    public List<ScenicSpotSimpleDTO> listScenicSpot() {
        return service.getAllScenicSpot().stream()
                .map(spot -> new ScenicSpotSimpleDTO(spot.getName(), spot.getIntro(), spot.getImageUrl(),spot.getAudioUrl()))
                .collect(Collectors.toList());
    }

    @PostMapping("/add")
    public ResponseEntity<String> addScenicSpot(@RequestBody ScenicSpot scenicspot) {
        service.addScenicSpot(scenicspot);
        return ResponseEntity.ok("景点添加成功");
    }
    @PostMapping("/delete")
    public Map<String, Object> deleteScenicSpot(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        Map<String, Object> result = new HashMap<>();

        if (name == null || name.trim().isEmpty()) {
            result.put("success", false);
            result.put("message", "景点名称不能为空");
            return result;
        }

        boolean success = service.deleteByName(name);
        result.put("success", success);
        result.put("message", success ? "删除成功" : "删除失败，可能名称不存在");
        return result;
    }
    @PostMapping("/update")
    public Map<String, Object> updateIntro(@RequestBody Map<String, String> body) {
        String name = body.get("name");
        String intro = body.get("intro");

        Map<String, Object> result = new HashMap<>();
        if (name == null || name.trim().isEmpty() || intro == null) {
            result.put("success", false);
            result.put("message", "景点名称和简介不能为空");
            return result;
        }

        boolean success = service.updateIntroByName(name, intro);
        result.put("success", success);
        result.put("message", success ? "更新成功" : "更新失败，可能名称不存在");
        return result;
    }

}