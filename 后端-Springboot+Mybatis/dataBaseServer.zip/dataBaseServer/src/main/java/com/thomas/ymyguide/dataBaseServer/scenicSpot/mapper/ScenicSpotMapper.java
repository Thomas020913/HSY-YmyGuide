package com.thomas.ymyguide.dataBaseServer.scenicSpot.mapper;

import com.thomas.ymyguide.dataBaseServer.scenicSpot.entity.ScenicSpot;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ScenicSpotMapper {
    @Insert("INSERT INTO scenic_spot(name, longitude, latitude, intro, image_url) " +
            "VALUES (#{name}, 1.0000, 1.0000, #{intro}, 'https://tse4-mm.cn.bing.net/th/id/OIP-C.j5yUH8eTdzgzwIhU2oT32AHaFj?cb=iwp1&rs=1&pid=ImgDetMain')")
    void insertScenicSpot(ScenicSpot spot);

    @Select("SELECT * FROM scenic_spot")
    List<ScenicSpot> getAllScenicSpots();

    @Delete("DELETE FROM scenic_spot WHERE name = #{name}")
    int deleteByName(String name);

    @Update("UPDATE scenic_spot SET intro = #{intro} WHERE name = #{name}")
    int updateIntroByName(String name, String intro);
}