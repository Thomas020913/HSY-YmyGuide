package com.thomas.ymyguide.dataBaseServer.user.repository;

import com.thomas.ymyguide.dataBaseServer.user.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByPhone(String identifier);

    Optional<User> findByUsername(String identifier);

    boolean existsByUsername(String username);
    boolean existsByPhone(String phone);
}
