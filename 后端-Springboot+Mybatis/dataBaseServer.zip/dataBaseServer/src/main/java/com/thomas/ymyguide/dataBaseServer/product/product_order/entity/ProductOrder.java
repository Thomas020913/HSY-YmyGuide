package com.thomas.ymyguide.dataBaseServer.product.product_order.entity;

import java.sql.Timestamp;
import java.math.BigDecimal;

public class ProductOrder {
    private Integer orderId; // 自增主键
    private String orderNumber; // 客户端生成订单号
    private Integer quantity;
    private BigDecimal totalPrice;
    private String orderStatus;
    private Timestamp paymentTime;

    public Integer getOrderId() { return orderId; }
    public void setOrderId(Integer orderId) { this.orderId = orderId; }
    public String getOrderNumber() { return orderNumber; }
    public void setOrderNumber(String orderNumber) { this.orderNumber = orderNumber; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
    public BigDecimal getTotalPrice() { return totalPrice; }
    public void setTotalPrice(BigDecimal totalPrice) { this.totalPrice = totalPrice; }
    public String getOrderStatus() { return orderStatus; }
    public void setOrderStatus(String orderStatus) { this.orderStatus = orderStatus; }
    public Timestamp getPaymentTime() { return paymentTime; }
    public void setPaymentTime(Timestamp paymentTime) { this.paymentTime = paymentTime; }
} 