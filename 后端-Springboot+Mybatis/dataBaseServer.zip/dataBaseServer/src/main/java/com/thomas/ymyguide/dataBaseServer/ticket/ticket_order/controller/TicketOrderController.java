package com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.controller;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.entity.TicketOrder;
import com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.service.TicketOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.math.BigDecimal;
import java.sql.Timestamp;

@RestController
@RequestMapping("/api/ticket_order")
public class TicketOrderController {

    @Autowired
    private TicketOrderService service;

    @PostMapping("/create")
    public ResponseEntity<?> createOrder(@RequestBody Map<String, Object> map) {
        String orderNumber = (String) map.get("orderNumber");
        String ticketType = (String) map.get("ticketType");
        BigDecimal ticketPrice = new BigDecimal(map.get("ticketPrice").toString());
        Integer quantity = (Integer) map.get("quantity");
        BigDecimal totalAmount = ticketPrice.multiply(BigDecimal.valueOf(quantity));
        String orderStatus = (String) map.getOrDefault("orderStatus", "未核销");
        Timestamp createTime = new Timestamp(System.currentTimeMillis());

        TicketOrder order = new TicketOrder();
        order.setOrderNumber(orderNumber);
        order.setTicketType(ticketType);
        order.setTicketPrice(ticketPrice);
        order.setQuantity(quantity);
        order.setTotalAmount(totalAmount);
        order.setOrderStatus(orderStatus);
        order.setCreateTime(createTime);

        service.createOrder(order);
        return ResponseEntity.ok("success");
    }

    @GetMapping("/list")
    public ResponseEntity<List<TicketOrder>> listOrders() {
        List<TicketOrder> orders = service.getAllOrders();
        return ResponseEntity.ok(orders);
    }

    @PostMapping("/updateStatus")
    public ResponseEntity<?> updateOrderStatus(@RequestBody Map<String, Object> map) {
        String orderNumber = (String) map.get("orderNumber");
        String orderStatus = (String) map.get("orderStatus");
        service.updateOrderStatus(orderNumber, orderStatus);
        return ResponseEntity.ok("订单状态更新成功");
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyOrder(@RequestBody Map<String, Object> map) {
        String orderNumber = (String) map.get("orderNumber");
        if (orderNumber == null || orderNumber.trim().isEmpty()) {
            return ResponseEntity.badRequest().body("orderNumber is required");
        }
        String result = service.verifyOrder(orderNumber);
        switch (result) {
            case "success":
                return ResponseEntity.ok("success");
            case "already verified":
                return ResponseEntity.ok("already verified");
            case "not found":
                return ResponseEntity.ok("not found");
            default:
                return ResponseEntity.status(500).body("verify failed");
        }
    }
} 