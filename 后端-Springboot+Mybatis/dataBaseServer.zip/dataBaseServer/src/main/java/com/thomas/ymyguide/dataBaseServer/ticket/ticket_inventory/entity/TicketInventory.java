package com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.entity;

import lombok.Data;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Data
public class TicketInventory {
    private Integer id;
    private String ticketName;
    private String ticketType;
    private BigDecimal price;
    private Integer currentStock;
    private Integer totalStock;
    private Integer validDate;
    private Boolean isRefundable;
    private Timestamp createTime;
}

