package com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.mapper;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.entity.TicketOrder;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.data.repository.query.Param;

import java.util.List;

@Mapper
public interface TicketOrderMapper {
    TicketOrder selectByOrderNumber(@Param("orderNumber") String orderNumber);

    void insertOrder(TicketOrder order);

    void updateOrderStatus(@Param("orderNumber") String orderNumber, @Param("orderStatus") String orderStatus);

    @Select("SELECT * FROM ticket_order")
    List<TicketOrder> getAllTicketOrders();
} 