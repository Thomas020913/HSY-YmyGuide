package com.thomas.ymyguide.dataBaseServer.product.product_order.service;

import com.thomas.ymyguide.dataBaseServer.product.product_order.entity.ProductOrder;
import com.thomas.ymyguide.dataBaseServer.product.product_order.mapper.ProductOrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductOrderService {
    @Autowired
    private ProductOrderMapper mapper;

    public boolean createOrder(ProductOrder order) {
        return mapper.insertOrder(order);
    }

    public boolean verifyAndUpdateOrder(String orderNumber, String status) {
        // 先检查订单是否存在
        ProductOrder order = mapper.getOrderByNumber(orderNumber);
        if (order == null) {
            return false;
        }
        
        // 更新订单状态
        return mapper.updateOrderStatus(orderNumber, status);
    }
} 