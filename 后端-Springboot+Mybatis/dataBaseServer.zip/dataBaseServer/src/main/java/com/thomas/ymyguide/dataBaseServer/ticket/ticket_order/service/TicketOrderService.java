package com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.service;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.entity.TicketOrder;
import com.thomas.ymyguide.dataBaseServer.ticket.ticket_order.mapper.TicketOrderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TicketOrderService {
    @Autowired
    private TicketOrderMapper ticketOrderMapper;

    public void createOrder(TicketOrder order) {
        ticketOrderMapper.insertOrder(order);
    }

    public void updateOrderStatus(String orderNumber, String orderStatus) {
        ticketOrderMapper.updateOrderStatus(orderNumber, orderStatus);
    }

    public TicketOrder getOrderByOrderNumber(String orderNumber) {
        return ticketOrderMapper.selectByOrderNumber(orderNumber);
    }

    public List<TicketOrder> getAllOrders() {
        return ticketOrderMapper.getAllTicketOrders();
    }

    public String verifyOrder(String orderNumber) {
        TicketOrder order = ticketOrderMapper.selectByOrderNumber(orderNumber);
        if (order == null) {
            return "not found";
        }
        if ("已核销".equals(order.getOrderStatus())) {
            return "already verified";
        }
        ticketOrderMapper.updateOrderStatus(orderNumber, "已核销");
        return "success";
    }
} 