package com.thomas.ymyguide.dataBaseServer.product.product_inventory.mapper;

import com.thomas.ymyguide.dataBaseServer.product.product_inventory.entity.Product;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ProductMapper {
    @Insert("INSERT INTO product_info(product_name, category, price, stock, image_url, scenic_spot_id, description, is_on_sale) " +
            "VALUES (#{name}, #{category}, #{price}, #{stock}, #{imageUrl}, #{scenicSpotId}, '无', 1)")
    void insertProduct(Product product);

    @Delete("DELETE FROM product_info WHERE product_name = #{name}")
    void deleteProduct(Product product);

    @Select("SELECT " +
            "id, " +
            "product_name AS name, " +
            "category, " +
            "price, " +
            "description, " +
            "stock, " +
            "image_url AS imageUrl, " +
            "scenic_spot_id AS scenicSpotId, " +
            "is_on_sale AS isOnSale, " +
            "create_time AS createTime " +
            "FROM product_info")
    List<Product> getAllProducts();

    Product getProductById(@Param("productId") Integer productId);

    @Update("UPDATE product_info SET stock = stock + #{quantity} WHERE product_name = #{productName}")
    int updateProductStock(@Param("productName") String productName, @Param("quantity") Integer quantity);
}
