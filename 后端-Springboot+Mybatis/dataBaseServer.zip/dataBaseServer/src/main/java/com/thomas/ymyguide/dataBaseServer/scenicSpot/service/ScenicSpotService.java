package com.thomas.ymyguide.dataBaseServer.scenicSpot.service;

import com.thomas.ymyguide.dataBaseServer.scenicSpot.entity.ScenicSpot;
import com.thomas.ymyguide.dataBaseServer.scenicSpot.mapper.ScenicSpotMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScenicSpotService {
    @Autowired
    private ScenicSpotMapper mapper;

    public List<ScenicSpot> getAllScenicSpot() { return mapper.getAllScenicSpots(); }

    public void addScenicSpot(ScenicSpot scenicspot) { mapper.insertScenicSpot(scenicspot); }

    public boolean deleteByName(String name) {
        return mapper.deleteByName(name) > 0;
    }
    public boolean updateIntroByName(String name, String intro) {
        return mapper.updateIntroByName(name, intro) > 0;
    }

}