package com.thomas.ymyguide.dataBaseServer.user.service;

import com.thomas.ymyguide.dataBaseServer.user.entity.UserRequest;
import com.thomas.ymyguide.dataBaseServer.user.dto.ResponseData;
import com.thomas.ymyguide.dataBaseServer.user.entity.User;
import com.thomas.ymyguide.dataBaseServer.user.repository.UserRepository;
import com.thomas.ymyguide.dataBaseServer.user.util.Md5Util;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    /**
     * 校验用户名和密码是否正确
     *
     * @return 成功返回role（1、2、3），失败返回0
     */
    public int validateLogin(String identifier, String rawPassword) {
        Optional<User> optionalUser;
        if (identifier.matches("^\\d{10,}$")) {
            optionalUser = userRepository.findByPhone(identifier);
        } else {
            optionalUser = userRepository.findByUsername(identifier);

            String md5Password = Md5Util.md5(rawPassword);

            if (optionalUser.isPresent()) {
                User user = optionalUser.get();
                if (user.getPassword().equals(md5Password)) {
                    return user.getRole();
                }
            }
        }
        return 0;
    }
    public ResponseData registerUser(UserRequest registerRequest) {
        // 检查用户名和手机号是否已存在
        if (userRepository.existsByUsername(registerRequest.getUsername())) {
            return new ResponseData(false, "注册失败：用户名已存在，请重试");
        }
        if (userRepository.existsByPhone(registerRequest.getPhone())) {
            return new ResponseData(false, "注册失败：手机号已存在，请重试");
        }

        // 使用MD5加密密码
        String encryptedPassword = Md5Util.md5(registerRequest.getPassword());

        // 创建新用户对象并保存到数据库
        User user = new User();
        user.setUsername(registerRequest.getUsername());
        user.setPhone(registerRequest.getPhone());
        user.setPassword(encryptedPassword);
        user.setRole(1);

        userRepository.save(user);
        return new ResponseData(true,"注册成功！");
    }
}