package com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.controller;

import com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.entity.TicketInventory;
import com.thomas.ymyguide.dataBaseServer.ticket.ticket_inventory.service.TicketInventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;
import java.util.Map;
import java.math.BigDecimal;

@RestController
@RequestMapping("/api/ticket")
public class TicketInventoryController {

    @Autowired
    private TicketInventoryService service;

    @PostMapping("/add")
    public ResponseEntity<?> addTicket(@RequestBody Map<String, Object> map) {
        String ticketName = (String) map.get("ticketName");
        String ticketType = (String) map.get("ticketType");
        String operationType = (String) map.get("operationType");
        int addStock = (int) map.get("addStock");

        TicketInventory ticket = new TicketInventory();
        ticket.setTicketName(ticketName);
        ticket.setTicketType(ticketType);

        if (operationType.equals("增加")){
            service.addOrUpdateTicket(ticket, addStock);
        }
        if (operationType.equals("删除")){
            service.delOrUpdateTicket(ticket, -addStock);
        }

        return ResponseEntity.ok("操作成功");
    }

    @GetMapping("/list")
    public ResponseEntity<List<TicketInventory>> listTicketInventory() {
        List<TicketInventory> tickets = service.getAllTicketInventory();
        return ResponseEntity.ok(tickets);
    }
    @PostMapping("/update")
    public ResponseEntity<?> updateStockAfterPurchase(@RequestBody Map<String, Object> map) {
        String ticketName = (String) map.get("parkName");
        String ticketType = (String) map.get("ticketType");
        int quantity = (int) map.get("quantity");

        boolean success = service.decreaseStock(ticketName, ticketType, quantity);
        if (success) {
            return ResponseEntity.ok("库存更新成功");
        } else {
            return ResponseEntity.status(400).body("库存不足或票种不存在");
        }
    }

}
