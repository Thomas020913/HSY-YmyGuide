package com.thomas.ymyguide.dataBaseServer;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@MapperScan("com.thomas.ymyguide.dataBaseServer.**.mapper")
@EnableJpaRepositories(basePackages = "com.thomas.ymyguide.dataBaseServer.**.repository") // 只扫描 JPA 的 repository

public class DataBaseServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataBaseServerApplication.class, args);
	}

}
